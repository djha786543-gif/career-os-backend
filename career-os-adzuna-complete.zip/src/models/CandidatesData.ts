import { Candidate } from './Candidate';

export const candidates: Candidate[] = [
  {
    id: 'deobrat',
    name: 'Deobrat Jha',
    specialization: 'Senior Internal Auditor & Technology Risk Advisor',
    skills: [
      'SOX 404', 'ITGC', 'ITAC', 'COSO', 'COBIT',
      'ERP', 'SAP', 'Oracle', 'Workday', 'NetSuite',
      'AuditBoard', 'Onspring', 'process improvement', 'project management',
      'AWS', 'cloud security', 'AI governance', 'CISA', 'risk assessment',
      'IT audit', 'SoD', 'IT risk', 'compliance', 'cybersecurity'
    ],
    experienceYears: 12,
    regions: ['US', 'Europe', 'India'],
    preferences: {
      remote: true,
      hybrid: true,
      visaSponsorship: false,
      seniority: 'Senior'
    }
  },
  {
    id: 'pooja',
    name: 'Dr. Pooja Choubey',
    specialization: 'Molecular Genetics & Cardiovascular Research Scientist',
    skills: [], // populated per-track from PoojaProfiles
    experienceYears: 10,
    regions: ['US', 'Europe', 'India'],
    preferences: {
      visaSponsorship: true
    }
  }
];
